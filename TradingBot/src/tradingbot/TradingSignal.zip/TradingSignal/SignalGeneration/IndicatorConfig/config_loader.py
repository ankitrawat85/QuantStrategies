
from __future__ import annotations
import json
from dataclasses import dataclass
from typing import Dict, Tuple, List, Any, Optional

# Backward-compatible loader + strict resolver with method → global fallback.

ALIASES: Dict[str, str] = {
    "huber_delta": "epsilon",
    "max_angle_deg": "angle_max_deg",
}

def _first_present(d: dict, keys: List[str], default=None):
    for k in keys:
        if k in d: return d[k]
    return default

def _apply_aliases(d: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(d)
    for src, dst in ALIASES.items():
        if src in out and dst not in out:
            out[dst] = out[src]
    return out

def _derive_missing(method: str, params: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(params)
    if method.lower() == "hough":
        if "angle_max_deg" in out and "angle_min_deg" not in out:
            try:
                out["angle_min_deg"] = -float(out["angle_max_deg"])
            except Exception:
                pass
    return out

REQUIRED_BY_METHOD: Dict[str, Tuple[str, ...]] = {
    "ols": ("base_window", "tol_pct"),
    "huber": ("base_window", "epsilon", "tol_pct"),
    "ols_shift_min": ("base_window", "tol_pct"),
    "ols_envelop": ("base_window", "env_mode", "env_k", "tol_pct"),
    "hough": ("base_window", "pivot_span", "min_touches", "tol_pct", "max_violations", "angle_max_deg"),
}

def load_tlc_config(path: str) -> Tuple[List[str], Dict[str, dict]]:
    """
    Load config JSON and return (methods_list, params_by_method) with strict fallback:
      - method-specific block under cfg["methods"][method]
      - otherwise global top-level keys in cfg
    Raises KeyError if a required key for a method is absent in both.
    """
    with open(path, "r") as f:
        cfg = json.load(f)

    # Methods to run
    methods_list: List[str] = cfg.get("methods_to_run") or list((cfg.get("methods") or {}).keys())

    # Prepare per-method params
    params_by_method: Dict[str, dict] = {}
    methods_map: Dict[str, dict] = cfg.get("methods") or {}
    global_cfg = {k: v for k, v in cfg.items() if k not in ("methods","methods_to_run")}

    for m in methods_list:
        meth_cfg = dict(methods_map.get(m, {}))
        meth_cfg = _apply_aliases(meth_cfg)
        g = _apply_aliases(global_cfg)
        merged = dict(g); merged.update(meth_cfg)
        merged = _derive_missing(m, merged)

        missing = [k for k in REQUIRED_BY_METHOD.get(m, ()) if k not in merged]
        if missing:
            raise KeyError(f"Missing required config for method '{m}': {missing}. Provide them in methods.{m} or top-level.")

        params_by_method[m] = merged

    return methods_list, params_by_method
