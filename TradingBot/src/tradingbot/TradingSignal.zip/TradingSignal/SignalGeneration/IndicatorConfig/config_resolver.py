
from __future__ import annotations
import json
from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple

# ---- Aliases & derivations -------------------------------------------------

ALIASES: Dict[str, str] = {
    # map config key -> method param key
    "huber_delta": "epsilon",     # tlc JSON uses huber_delta; HuberRegressor expects epsilon
    "max_angle_deg": "angle_max_deg",
}

def _apply_aliases(d: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(d)
    for src, dst in ALIASES.items():
        if src in out and dst not in out:
            out[dst] = out[src]
    return out

def _derive_missing(method: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Fill computable fields if logically implied by others."""
    out = dict(params)
    if method.lower() == "hough":
        # If min angle is unspecified but max is provided, mirror it.
        if "angle_max_deg" in out and "angle_min_deg" not in out:
            try:
                out["angle_min_deg"] = -float(out["angle_max_deg"])
            except Exception:
                pass
    return out

# ---- Requirements per method ----------------------------------------------

REQUIRED_BY_METHOD: Dict[str, Tuple[str, ...]] = {
    "ols": ("base_window", "tol_pct"),
    "huber": ("base_window", "epsilon", "tol_pct"),  # epsilon may come from huber_delta
    "ols_shift_min": ("base_window", "tol_pct"),
    "ols_envelop": ("base_window", "env_mode", "env_k", "tol_pct"),
    "hough": ("base_window", "pivot_span", "min_touches", "tol_pct", "max_violations", "angle_max_deg"),
}

OPTIONAL_KEYS = {
    # keys allowed to default inside plugin if not provided
    "ols": ("tol_mode", "tol_atr_len", "tol_atr_k", "emit_touch", "emit_bounce"),
    "huber": ("tol_mode", "tol_atr_len", "tol_atr_k", "emit_touch", "emit_bounce"),
    "ols_shift_min": ("emit_touch", "emit_bounce"),
    "ols_envelop": ("env_base", "emit_touch"),
    "hough": ("emit_touch", "emit_bounce", "angle_min_deg"),
}

@dataclass
class ResolutionResult:
    method: str
    params: Dict[str, Any]

class ConfigError(KeyError):
    pass

# ---- Main resolver ---------------------------------------------------------

def load_config_json(path: str) -> Dict[str, Any]:
    with open(path, "r") as f:
        cfg = json.load(f)
    return cfg

def get_methods_list(cfg: Dict[str, Any]) -> Tuple[list, Dict[str, Dict[str, Any]]]:
    """Return (methods_to_run, method_overrides) from tlc_config_methods.json-like file."""
    # prefer explicit list
    if "methods_to_run" in cfg and isinstance(cfg["methods_to_run"], list):
        methods_list = cfg["methods_to_run"]
    else:
        # or derive from methods mapping
        methods_list = sorted(list(cfg.get("methods", {}).keys()))
    return methods_list, cfg.get("methods", {})

def resolve_params_for_method(
    method: str,
    cfg: Dict[str, Any],
    strict: bool = True,
) -> ResolutionResult:
    """
    Merge params for a given method with fallbacks:
      1) method-specific: cfg["methods"][method]
      2) global:          cfg[...] (top-level keys)
    If a required key is missing in both, raise ConfigError (when strict=True).
    """
    methods_map = cfg.get("methods", {}) or {}

    meth_cfg = dict(methods_map.get(method, {}))
    global_cfg = {k: v for k, v in cfg.items()
                  if k != "methods" and k != "methods_to_run"}  # globals

    # alias stage first on both
    meth_cfg = _apply_aliases(meth_cfg)
    global_cfg = _apply_aliases(global_cfg)

    # merged (method overrides global)
    merged = dict(global_cfg)
    merged.update(meth_cfg)

    # derivations that depend on *the merged* view
    merged = _derive_missing(method, merged)

    # validate required
    req = REQUIRED_BY_METHOD.get(method.lower(), ())
    missing = [k for k in req if k not in merged]
    if strict and missing:
        raise ConfigError(
            f"Missing required config for method '{method}': {missing}. "
            f"Provide them under methods.{method} or at top-level."
        )

    # Keep only keys that are relevant (required + optional) for cleanliness,
    # but don't drop user extras if strict==False.
    allowed = set(req) | set(OPTIONAL_KEYS.get(method.lower(), ()))
    pruned = {k: merged[k] for k in merged if (not strict) or (k in allowed)}

    return ResolutionResult(method=method, params=pruned)

def resolve_all_methods(cfg: Dict[str, Any], methods: Optional[list] = None, strict: bool = True) -> Dict[str, Dict[str, Any]]:
    if methods is None:
        methods, _ = get_methods_list(cfg)
    out: Dict[str, Dict[str, Any]] = {}
    for m in methods:
        out[m] = resolve_params_for_method(m, cfg, strict=strict).params
    return out

def get_post_params(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Parameters for post-processing steps like CREATE/BREAK/EXPIRY synthesis."""
    keep = ("expiry_after","expiry_on_break","persist_n","retest_window",
            "w_pen","w_pers","w_retest","min_confidence")
    return {k: v for k, v in cfg.items() if k in keep}
