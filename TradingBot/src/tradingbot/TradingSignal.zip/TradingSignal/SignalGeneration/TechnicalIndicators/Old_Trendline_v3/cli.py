
from __future__ import annotations
import argparse, json, sys
import pandas as pd

from .runner import run_methods
from .registry import available_methods
from ...IndicatorConfig.config_loader import load_tlc_config
from .plot.plot import plot_trendlines
import os

def parse_args():
    ap = argparse.ArgumentParser(description="Pluggable trendline runner")
    ap.add_argument("--csv", required=True, help="OHLC CSV with columns date,open,high,low,close")
    ap.add_argument("--methods", help="Comma-separated method names")
    ap.add_argument("--params", help="JSON of {method: {param: value}}")
    ap.add_argument("--config", help="Path to tlc_config_methods.json")
    ap.add_argument("--plot-out", help="If set, save trendline overlay plot (per method). If a directory, files are named \'<out-prefix>_<method>_plot.png\'.")
    ap.add_argument("--title", help="Plot title override.", default=None)
    return ap.parse_args()

def main():
    args = parse_args()
    df = pd.read_csv(args.csv)
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date")

    methods = []
    params_by_method = {}

    if args.config:
        m_from_cfg, p_from_cfg = load_tlc_config(args.config)
        methods = m_from_cfg or methods
        params_by_method.update(p_from_cfg or {})

    if args.methods:
        methods_cli = [m.strip() for m in args.methods.split(",") if m.strip()]
        # If both provided, intersect to run only requested methods
        methods = methods_cli if not methods else [m for m in methods_cli if m in methods]

    if args.params:
        params_cli = json.loads(args.params)
        params_by_method.update(params_cli)

    if not methods:
        print("ERROR: No methods specified. Use --methods or provide a config with methods.", file=sys.stderr)
        print("Available:", available_methods(), file=sys.stderr)
        sys.exit(2)

    results = run_methods(df, methods, params_by_method)

    for m, res in results.items():
        res.lines.to_csv(f"{args.out_prefix}_{m}_lines.csv", index=False)
        \1
        if args.plot_out:
            if os.path.isdir(args.plot_out):
                plot_path = os.path.join(args.plot_out, f"{os.path.basename(args.out_prefix)}_{m}_plot.png")
            else:
                plot_path = args.plot_out if len(methods) == 1 else f"{args.plot_out}_{m}.png"
            plot_trendlines(df, res.lines, res.events, args.title or f"{m.upper()} — Trendlines", plot_path)

    print("Done. Methods:", methods)
    print("Available methods:", available_methods())

if __name__ == "__main__":
    main()
