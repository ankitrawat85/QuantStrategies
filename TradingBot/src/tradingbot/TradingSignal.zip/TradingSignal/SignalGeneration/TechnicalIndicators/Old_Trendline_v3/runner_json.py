
from __future__ import annotations
from typing import Iterable, Dict, Optional
import pandas as pd

from .runner import run_single
from .registry import available_methods
from .types import MethodResult

from ...IndicatorConfig.config_resolver import load_config_json, get_methods_list, resolve_all_methods

def run_from_json(ohlc: pd.DataFrame, json_path: str, methods: Optional[Iterable[str]] = None, strict: bool = True) -> Dict[str, MethodResult]:
    """
    Convenience: load tlc_config_methods.json, resolve per-method params with fallback
    (method block → global), then run each selected method.
    """
    cfg = load_config_json(json_path)
    meths_file, _ = get_methods_list(cfg)
    chosen = list(methods) if methods else meths_file
    # sanity check
    avail = set(available_methods())
    bad = [m for m in chosen if m not in avail]
    if bad:
        raise KeyError(f"Unknown method(s) {bad}. Registered: {sorted(avail)}")

    params_by_method = resolve_all_methods(cfg, methods=chosen, strict=strict)
    results: Dict[str, MethodResult] = {}
    for m in chosen:
        results[m] = run_single(ohlc, m, params_by_method[m])
    return results
