
from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import asdict
from math import atan, degrees

from ..registry import register_method
from ..types import LineFit, Event, MethodResult, MethodParams


@register_method("hough")
def _ctor():
    return Hough()


class Hough:
    name = "hough"

    def run(self, ohlc: pd.DataFrame, params: MethodParams) -> MethodResult:
        df = ohlc.copy()
        win = int(params.get("base_window", 120))
        pivot_span = int(params.get("pivot_span", 30))
        min_touches = int(params.get("min_touches", 2))
        tol_pct = float(params.get("tol_pct", 0.01))
        max_violations = int(params.get("max_violations", 10))
        angle_min_deg = float(params.get("angle_min_deg", -70.0))
        angle_max_deg = float(params.get("angle_max_deg", 70.0))

        n = len(df)
        if n < max(win, 2*pivot_span+1):
            return MethodResult(lines=pd.DataFrame(columns=['id','side','m','b','start_idx','end_idx','r2','meta']),
                                events=pd.DataFrame(columns=['event','side','idx','date','price','confidence','method','line_id','meta']))

        close = df['close'].to_numpy()
        high = df['high'].to_numpy()
        low = df['low'].to_numpy()
        idx = np.arange(n)
        dates = df.index

        def pivot_mask(arr: np.ndarray, span: int, mode: str) -> np.ndarray:
            s = pd.Series(arr)
            if mode == 'high':
                r = s.rolling(2*span+1, center=True, min_periods=1).max()
                return (s == r).values
            else:
                r = s.rolling(2*span+1, center=True, min_periods=1).min()
                return (s == r).values

        pH_mask = pivot_mask(high, pivot_span, 'high')
        pL_mask = pivot_mask(low, pivot_span, 'low')

        lines, events = [], []

        def fit_sr(side: str):
            piv_mask = pH_mask if side == 'R' else pL_mask
            ysrc = high if side == 'R' else low
            for end in range(win, n+1):
                start = end - win
                piv_idx = idx[start:end][piv_mask[start:end]]
                if len(piv_idx) < min_touches: continue
                xi = piv_idx.astype(float); yi = ysrc[piv_idx].astype(float)

                xm = xi.mean(); ym = yi.mean()
                denom = ((xi - xm)**2).sum() or 1.0
                m = float(((xi - xm)*(yi - ym)).sum() / denom)
                b = float(ym - m*xm)

                xw = idx[start:end].astype(float); yw = ysrc[start:end].astype(float)
                if side == 'R':
                    b = float(np.max(yw - m*xw))
                else:
                    b = float(np.min(yw - m*xw))

                ang = degrees(atan(m))
                if not (angle_min_deg <= ang <= angle_max_deg): continue

                mid_px = float(np.median(close[start:end]))
                tol_abs = mid_px * tol_pct

                # touches count within tolerance on pivots
                yhat_p = m*xi + b
                touches = int(np.sum(np.abs(yi - yhat_p) <= tol_abs))
                if touches < min_touches: continue

                # violations on window
                yhat_w = m*xw + b
                if side == 'R':
                    viol = int(np.sum(high[start:end] > (yhat_w + tol_abs)))
                else:
                    viol = int(np.sum(low[start:end] < (yhat_w - tol_abs)))
                if viol > max_violations: continue

                ssr = float(((yi - yhat_p)**2).sum())
                sst = float(((yi - yi.mean())**2).sum()) or 1.0
                r2 = max(0.0, 1.0 - ssr/sst)

                line_id = f"{side}_{start}_{end-1}"
                lines.append(LineFit(id=line_id, side=side, m=m, b=b, start_idx=start, end_idx=end-1, r2=r2,
                                     meta={"touches": touches, "violations": viol, "angle_deg": ang, "tol_abs": tol_abs}))

                # --- events (create + true crossing, optional touch/bounce) ---
                # CREATE at end_idx
                events.append(Event(
                    event="create", side="NONE", idx=end-1, date=dates[end-1], price=float(close[end-1]),
                    confidence=float(max(0.0, min(1.0, r2))), method=self.name, line_id=line_id,
                    meta={"angle_deg": ang, "touches": touches, "violations": viol, "tol_abs": tol_abs}
                ))

                price = float(close[end-1]); line_px = m*(end-1)+b
                prev_i = end - 2
                prev_price = float(close[prev_i]) if prev_i >= 0 else price
                prev_line_px = float(m*prev_i + b) if prev_i >= 0 else line_px

                if side == 'R':
                    crossed = (prev_price <= prev_line_px + tol_abs) and (price > line_px + tol_abs)
                    touched = (not crossed) and (high[end-1] >= line_px - tol_abs) and (price <= line_px + tol_abs)
                    bounced = touched and (price < prev_price) and (price <= line_px - tol_abs)
                else:
                    crossed = (prev_price >= prev_line_px - tol_abs) and (price < line_px - tol_abs)
                    touched = (not crossed) and (low[end-1] <= line_px + tol_abs) and (price >= line_px - tol_abs)
                    bounced = touched and (price > prev_price) and (price >= line_px + tol_abs)

                if crossed:
                    events.append(Event(
                        event="break", side=("BUY" if side=='R' else "SELL"),
                        idx=end-1, date=dates[end-1], price=price,
                        confidence=min(1.0, max(0.0, abs(price-line_px)/max(1e-9, abs(line_px)))),
                        method=self.name, line_id=line_id,
                        meta={"angle_deg": ang, "touches": touches, "violations": viol, "r2": r2, "tol_abs": tol_abs}
                    ))
                else:
                    if bool(params.get("emit_bounce", True)) and bounced:
                        events.append(Event(
                            event="bounce", side=("SELL" if side=='R' else "BUY"),
                            idx=end-1, date=dates[end-1], price=price, confidence=0.5,
                            method=self.name, line_id=line_id,
                            meta={"angle_deg": ang, "touches": touches, "violations": viol, "r2": r2, "tol_abs": tol_abs}
                        ))
                    if bool(params.get("emit_touch", True)) and touched:
                        events.append(Event(
                            event="touch", side=("SELL" if side=='R' else "BUY"),
                            idx=end-1, date=dates[end-1], price=price, confidence=0.3,
                            method=self.name, line_id=line_id,
                            meta={"angle_deg": ang, "touches": touches, "violations": viol, "r2": r2, "tol_abs": tol_abs}
                        ))

        fit_sr('R'); fit_sr('S')
        lines_df = pd.DataFrame([asdict(l) for l in lines]) if lines else pd.DataFrame(columns=['id','side','m','b','start_idx','end_idx','r2','meta'])
        events_df = pd.DataFrame([asdict(e) for e in events]) if events else pd.DataFrame(columns=['event','side','idx','date','price','confidence','method','line_id','meta'])
        return MethodResult(lines=lines_df, events=events_df)
