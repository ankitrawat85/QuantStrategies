
from .types import Touch, LineFit, Event, MethodResult, MethodParams
from .interfaces import TrendlineMethod
from .registry import register_method, get_method, available_methods
from .runner import run_methods, run_single, MethodsConfig
# ⬇️ make sure these imports exist and point to YOUR method modules
from .methods import ols, huber, hough, ols_shift_min, ols_envelop