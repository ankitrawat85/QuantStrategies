
from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import asdict
from sklearn.linear_model import LinearRegression

from ..registry import register_method
from ..types import LineFit, Event, MethodResult, MethodParams


@register_method("ols_shift_min")
def _ctor():
    return OLSShiftMin()


class OLSShiftMin:
    name = "ols_shift_min"

    def run(self, ohlc: pd.DataFrame, params: MethodParams) -> MethodResult:
        win = int(params.get("base_window", 40))
        x = np.arange(len(ohlc)); X = x.reshape(-1,1)

        lines, events = [], []
        close_s = ohlc["close"]; high_s = ohlc["high"]; low_s = ohlc["low"]

        def roll_fit(y: np.ndarray, side: str):
            if len(y) < win: return
            lr = LinearRegression()
            for i in range(win, len(y)+1):
                yi = y[i-win:i]; xi = X[i-win:i]
                lr.fit(xi, yi)
                m = float(lr.coef_[0]); b = float(lr.intercept_)
                if side == 'R':
                    b2 = float(np.max(yi - m*xi.flatten()))
                else:
                    b2 = float(np.min(yi - m*xi.flatten()))
                m2 = m

                line_id = f"{side}_{i-win}_{i-1}"
                # r2 vs shifted line
                yhat = m2*xi.flatten() + b2
                ssr = float(((yi - yhat)**2).sum()); sst = float(((yi - yi.mean())**2).sum()) or 1.0
                r2 = max(0.0, 1.0 - ssr/sst)

                lines.append(LineFit(id=line_id, side=side, m=m2, b=b2, start_idx=i-win, end_idx=i-1, r2=r2, meta={"shifted": True}))

                # events: create + true cross + optional touch/bounce
                price = float(close_s.iloc[i-1]); line_px = m2*(i-1)+b2
                tol_pct = float(params.get("tol_pct", 0.005))
                mid_px = float(close_s.iloc[max(0, i-win):i].median())
                tol_abs = mid_px * tol_pct

                events.append(Event(event="create", side="NONE", idx=i-1, date=ohlc.index[i-1], price=price,
                                    confidence=float(max(0.0, min(1.0, r2))), method=self.name, line_id=line_id,
                                    meta={"r2": r2, "tol_abs": tol_abs}))

                prev_i = i - 2
                prev_price = float(close_s.iloc[prev_i]) if prev_i >= 0 else price
                prev_line_px = float(m2*prev_i + b2) if prev_i >= 0 else line_px

                if side == 'R':
                    crossed = (prev_price <= prev_line_px + tol_abs) and (price > line_px + tol_abs)
                    touched = (not crossed) and (high_s.iloc[i - 1] >= line_px - tol_abs) and (price <= line_px + tol_abs)
                    bounced = touched and (price < prev_price) and (price <= line_px - tol_abs)
                else:
                    crossed = (prev_price >= prev_line_px - tol_abs) and (price < line_px - tol_abs)
                    touched = (not crossed) and (low_s.iloc[i - 1] <= line_px + tol_abs) and (price >= line_px - tol_abs)
                    bounced = touched and (price > prev_price) and (price >= line_px + tol_abs)

                if crossed:
                    events.append(Event(
                        event="break",
                        side=("BUY" if side=='R' else "SELL"),
                        idx=i-1, date=ohlc.index[i-1], price=price,
                        confidence=min(1.0, max(0.0, abs(price-line_px)/(abs(line_px)+1e-9))),
                        method=self.name, line_id=line_id, meta={"r2": r2, "tol_abs": tol_abs}
                    ))
                else:
                    if bool(params.get("emit_bounce", True)) and bounced:
                        events.append(Event(event="bounce", side=("SELL" if side=='R' else "BUY"),
                                            idx=i-1, date=ohlc.index[i-1], price=price, confidence=0.5,
                                            method=self.name, line_id=line_id, meta={"r2": r2, "tol_abs": tol_abs}))
                    if bool(params.get("emit_touch", True)) and touched:
                        events.append(Event(event="touch", side=("SELL" if side=='R' else "BUY"),
                                            idx=i-1, date=ohlc.index[i-1], price=price, confidence=0.3,
                                            method=self.name, line_id=line_id, meta={"r2": r2, "tol_abs": tol_abs}))

        roll_fit(ohlc['high'].to_numpy(), 'R')
        roll_fit(ohlc['low'].to_numpy(), 'S')
        lines_df = pd.DataFrame([asdict(l) for l in lines]) if lines else pd.DataFrame(columns=['id','side','m','b','start_idx','end_idx','r2','meta'])
        events_df = pd.DataFrame([asdict(e) for e in events]) if events else pd.DataFrame(columns=['event','side','idx','date','price','confidence','method','line_id','meta'])
        return MethodResult(lines=lines_df, events=events_df)
