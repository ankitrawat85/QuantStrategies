from __future__ import annotations
from typing import Dict, Any, Optional
import numpy as np
import pandas as pd

MAIN_SCHEMA_COLS = [
    "event","side","idx","date","price","m","b","start_idx","created_at",
    "touches","window_len","lookback_used","method","pivot_span",
    "confidence","penetration_score","persistence_score","retest_score","reason",
]

def _get_meta(row: pd.Series, key: str):
    val = None
    if isinstance(row.get("meta"), dict) and key in row["meta"]:
        val = row["meta"][key]
    if val is None and isinstance(row.get("line_meta"), dict) and key in row["line_meta"]:
        val = row["line_meta"][key]
    return val

def enrich_events_to_main_schema(
    events_df: pd.DataFrame,
    lines_df: pd.DataFrame,
    method_name: str = "",
    method_params: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    method_params = method_params or {}
    ev = events_df.copy()
    ln = lines_df.copy()

    if "date" in ev.columns:
        ev["date"] = pd.to_datetime(ev["date"], errors="coerce")
    ev["idx"] = pd.to_numeric(ev.get("idx"), errors="coerce")
    ev["price"] = pd.to_numeric(ev.get("price"), errors="coerce")

    join_cols = ["id","side","m","b","start_idx","meta"]
    ln_j = ln[join_cols].rename(columns={"id":"line_id","side":"side_sr","meta":"line_meta"})
    out = ev.merge(ln_j, on="line_id", how="left")

    out["side"] = out["side_sr"].fillna(out.get("side"))
    out["event"] = out["event"].astype(str).str.lower().replace({"expiry":"expire"})
    for c in ("m","b","start_idx"):
        out[c] = pd.to_numeric(out.get(c), errors="coerce")

    created_map = (
        out.loc[out["event"]=="create"].groupby("line_id")["date"].min()
    )
    out["created_at"] = out["line_id"].map(created_map)

    out["touches"] = out.apply(lambda r: _get_meta(r, "touches"), axis=1)

    win_meta = out.apply(lambda r: _get_meta(r, "window_len"), axis=1)
    seg_len = pd.to_numeric(out.get("end_idx"), errors="coerce") - pd.to_numeric(out.get("start_idx"), errors="coerce") + 1
    out["window_len"] = win_meta.where(win_meta.notna(), seg_len)

    out["lookback_used"] = out.apply(lambda r: _get_meta(r, "lookback_used"), axis=1)
    if out["lookback_used"].isna().all() and method_params.get("lookback_used") is not None:
        out["lookback_used"] = method_params.get("lookback_used")
    out["pivot_span"] = out.apply(lambda r: _get_meta(r, "pivot_span"), axis=1)
    if out["pivot_span"].isna().all() and method_params.get("pivot_span") is not None:
        out["pivot_span"] = method_params.get("pivot_span")

    out["reason"] = out.apply(lambda r: _get_meta(r, "reason"), axis=1)
    out["confidence"] = pd.to_numeric(out.get("confidence"), errors="coerce")

    for c in ("penetration_score","persistence_score","retest_score"):
        if c not in out.columns:
            out[c] = np.nan

    out["method"] = out.get("method").fillna(method_name)
    for c in MAIN_SCHEMA_COLS:
        if c not in out.columns:
            out[c] = np.nan
    return out[MAIN_SCHEMA_COLS]
