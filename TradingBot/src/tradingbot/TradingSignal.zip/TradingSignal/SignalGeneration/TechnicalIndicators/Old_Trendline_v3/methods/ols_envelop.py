
from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import asdict
from sklearn.linear_model import LinearRegression

from ..registry import register_method
from ..types import LineFit, Event, MethodResult, MethodParams


@register_method("ols_envelop")
def _ctor():
    return OLSEnvelop()


class OLSEnvelop:
    name = "ols_envelop"

    def run(self, ohlc: pd.DataFrame, params: MethodParams) -> MethodResult:
        win = int(params.get("base_window", 40))
        env_mode = str(params.get("env_mode", "atr"))  # 'atr'|'pct'|'abs'
        env_base = int(params.get("env_base", 14))
        env_k = float(params.get("env_k", 2.0))

        x = np.arange(len(ohlc)); X = x.reshape(-1,1)
        lines, events = [], []

        # compute ATR if needed
        def compute_atr(length: int=14):
            o = ohlc['open'].astype(float).values
            h = ohlc['high'].astype(float).values
            l = ohlc['low'].astype(float).values
            c = ohlc['close'].astype(float).values
            prev_c = np.roll(c, 1); prev_c[0] = c[0]
            tr = np.maximum.reduce([h - l, np.abs(h - prev_c), np.abs(l - prev_c)])
            atr = pd.Series(tr).rolling(length, min_periods=1).mean().values
            return atr
        atr = compute_atr(env_base) if env_mode == 'atr' else None

        close_s = ohlc['close']; high_s = ohlc['high']; low_s = ohlc['low']

        def roll_fit(mid: np.ndarray):
            if len(mid) < win: return
            lr = LinearRegression()
            for i in range(win, len(mid)+1):
                yi = mid[i-win:i]; xi = X[i-win:i]
                lr.fit(xi, yi)
                m = float(lr.coef_[0]); b = float(lr.intercept_)
                if env_mode == 'atr':
                    off = float(np.mean(atr[i-win:i]) * env_k)
                elif env_mode == 'pct':
                    off = float(np.mean(yi) * env_k)
                else:
                    off = float(env_k)

                # two lines: R and S
                line_id_R = f"R_{i-win}_{i-1}"
                line_id_S = f"S_{i-win}_{i-1}"
                lines.append(LineFit(id=line_id_R, side='R', m=m, b=b+off, start_idx=i-win, end_idx=i-1, r2=1.0, meta={"env_off": off}))
                lines.append(LineFit(id=line_id_S, side='S', m=m, b=b-off, start_idx=i-win, end_idx=i-1, r2=1.0, meta={"env_off": off}))

                # CREATE events for both
                price = float(close_s.iloc[i-1])
                tol_pct = float(params.get("tol_pct", 0.005))
                mid_px = float(close_s.iloc[max(0, i-win):i].median())
                tol_abs = mid_px * tol_pct

                events.append(Event(event="create", side="NONE", idx=i-1, date=ohlc.index[i-1], price=price,
                                    confidence=1.0, method=self.name, line_id=line_id_R, meta={"env_off": off, "tol_abs": tol_abs}))
                events.append(Event(event="create", side="NONE", idx=i-1, date=ohlc.index[i-1], price=price,
                                    confidence=1.0, method=self.name, line_id=line_id_S, meta={"env_off": off, "tol_abs": tol_abs}))

                # true crossing for both sides
                prev_i = i - 2
                prev_price = float(close_s.iloc[prev_i]) if prev_i >= 0 else price
                # resistance
                r_line_px_now = m*(i-1) + (b+off)
                r_line_px_prev = m*prev_i + (b+off) if prev_i >= 0 else r_line_px_now
                r_cross = (prev_price <= r_line_px_prev + tol_abs) and (price > r_line_px_now + tol_abs)
                # support
                s_line_px_now = m*(i-1) + (b-off)
                s_line_px_prev = m*prev_i + (b-off) if prev_i >= 0 else s_line_px_now
                s_cross = (prev_price >= s_line_px_prev - tol_abs) and (price < s_line_px_now - tol_abs)

                if r_cross:
                    events.append(Event(event="break", side="BUY", idx=i-1, date=ohlc.index[i-1], price=price,
                                        confidence=min(1.0, max(0.0, abs(price-r_line_px_now)/(abs(r_line_px_now)+1e-9))),
                                        method=self.name, line_id=line_id_R, meta={"env_off": off, "tol_abs": tol_abs}))
                elif bool(params.get("emit_touch", True)):
                    touched = (high_s.iloc[i-1] >= r_line_px_now - tol_abs) and (price <= r_line_px_now + tol_abs)
                    if touched:
                        events.append(Event(event="touch", side="SELL", idx=i-1, date=ohlc.index[i-1], price=price,
                                            confidence=0.3, method=self.name, line_id=line_id_R, meta={"env_off": off, "tol_abs": tol_abs}))

                if s_cross:
                    events.append(Event(event="break", side="SELL", idx=i-1, date=ohlc.index[i-1], price=price,
                                        confidence=min(1.0, max(0.0, abs(price-s_line_px_now)/(abs(s_line_px_now)+1e-9))),
                                        method=self.name, line_id=line_id_S, meta={"env_off": off, "tol_abs": tol_abs}))
                elif bool(params.get("emit_touch", True)):
                    touched = (low_s.iloc[i-1] <= s_line_px_now + tol_abs) and (price >= s_line_px_now - tol_abs)
                    if touched:
                        events.append(Event(event="touch", side="BUY", idx=i-1, date=ohlc.index[i-1], price=price,
                                            confidence=0.3, method=self.name, line_id=line_id_S, meta={"env_off": off, "tol_abs": tol_abs}))

        roll_fit(ohlc['close'].to_numpy())
        lines_df = pd.DataFrame([asdict(l) for l in lines]) if lines else pd.DataFrame(columns=['id','side','m','b','start_idx','end_idx','r2','meta'])
        events_df = pd.DataFrame([asdict(e) for e in events]) if events else pd.DataFrame(columns=['event','side','idx','date','price','confidence','method','line_id','meta'])
        return MethodResult(lines=lines_df, events=events_df)
