
from __future__ import annotations
from typing import Protocol, Dict, Any
import pandas as pd
from .types import MethodResult, MethodParams

class TrendlineMethod(Protocol):
    name: str

    def run(self, ohlc: pd.DataFrame, params: MethodParams) -> MethodResult:
        ...  # implement
