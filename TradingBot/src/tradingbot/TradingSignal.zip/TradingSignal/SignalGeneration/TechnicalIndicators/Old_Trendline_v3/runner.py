
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Iterable, Optional
import pandas as pd

from .registry import get_method
from .types import MethodParams, MethodResult

@dataclass
class MethodsConfig:
    # {"ols": {"base_window": 40, "min_touches": 2}, "hough": {...}}
    methods: Dict[str, Dict] 

def run_single(ohlc: pd.DataFrame, method_name: str, params: Optional[Dict]=None) -> MethodResult:
    plugin = get_method(method_name)
    p = MethodParams(params or {})
    return plugin.run(ohlc, p)

def run_methods(ohlc: pd.DataFrame, methods: Iterable[str], params_by_method: Optional[Dict[str, Dict]]=None) -> Dict[str, MethodResult]:
    results: Dict[str, MethodResult] = {}
    params_by_method = params_by_method or {}
    for m in methods:
        results[m] = run_single(ohlc, m, params_by_method.get(m, {}))
    return results
