
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import pandas as pd

@dataclass
class Touch:
    idx: int
    date: pd.Timestamp
    price: float

@dataclass
class LineFit:
    id: str
    side: str          # 'S' or 'R'
    m: float           # slope
    b: float           # intercept
    start_idx: int
    end_idx: int
    r2: float = 1.0
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Event:
    event: str        # e.g., 'touch', 'break', 'bounce'
    side: str         # 'BUY' or 'SELL'
    idx: int
    date: pd.Timestamp
    price: float
    confidence: float
    method: str
    line_id: Optional[str] = None
    meta: Dict[str, Any] = field(default_factory=dict)

@dataclass
class MethodResult:
    lines: pd.DataFrame   # rows of LineFit fields
    events: pd.DataFrame  # rows of Event fields

@dataclass
class MethodParams:
    # flexible bag of named params, surfaced to each plugin
    values: Dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default: Any=None) -> Any:
        return self.values.get(key, default)
