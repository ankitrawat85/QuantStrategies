from __future__ import annotations

import numpy as np
import pandas as pd


def synthesize_create_break_expiry(
    events: pd.DataFrame,
    lines: pd.DataFrame,
    cal_index: pd.DatetimeIndex,
    expiry_after: int | None = None,
    expiry_on_break: bool = True,
) -> pd.DataFrame:
    """
    Normalize event stream to contain CREATE, first BREAK, and EXPIRY.

    - CREATE: at each line's end_idx (if not already present).
    - BREAK: keep only the first 'break' per (method, line_id).
    - EXPIRY:
        * if expiry_on_break: expire on the first break bar.
        * else: expire after 'expiry_after' bars since end_idx (default = window length).
    """

    ev = events.copy()
    ln = lines.copy()

    # Ensure required cols exist
    for c in ["line_id", "event", "idx", "method"]:
        if c not in ev.columns:
            raise KeyError(f"events missing required column '{c}'")
    for c in ["id", "start_idx", "end_idx", "m", "b", "method"]:
        if c not in ln.columns:
            ln[c] = np.nan

    # ints
    for c in ["idx", "start_idx", "end_idx"]:
        if c in ev.columns:
            ev[c] = ev[c].astype("Int64")
        if c in ln.columns:
            ln[c] = ln[c].astype("Int64")

    # ---- first break per (method,line_id)
    ev_sorted = ev.sort_values(["method", "line_id", "idx"])
    breaks_first = (
        ev_sorted[ev_sorted["event"].str.lower() == "break"]
        .drop_duplicates(["method", "line_id"], keep="first")
    )

    # ---- create (ensure at least one per line at end_idx)
    existing_creates = (
        ev_sorted[ev_sorted["event"].str.lower() == "create"]
        .set_index(["method", "line_id"])
    )
    create_rows = []
    for _, row in ln.iterrows():
        key = (row.get("method"), row.get("id"))
        if key in existing_creates.index:
            continue
        end_i = int(row["end_idx"])
        create_rows.append({
            "event": "create",
            "side": "NONE",
            "idx": end_i,
            "date": cal_index[end_i] if isinstance(cal_index, pd.DatetimeIndex) else None,
            "price": np.nan,
            "confidence": float(max(0.0, min(1.0, row.get("r2", 1.0)))),
            "method": row.get("method"),
            "line_id": row.get("id"),
            "m": row.get("m"), "b": row.get("b"),
            "start_idx": row.get("start_idx"),
            "meta": {"source": "synth"}
        })
    create_df = pd.DataFrame(create_rows)

    # ---- expiry
    if expiry_after is None:
        ln["window_len"] = (ln["end_idx"] - ln["start_idx"] + 1).astype("Int64")
        expiry_after_map = ln.set_index("id")["window_len"].to_dict()
    else:
        expiry_after_map = expiry_after  # int for all

    first_break_idx = breaks_first.set_index(["method", "line_id"])["idx"].to_dict()

    expiry_rows = []
    for _, row in ln.iterrows():
        line_key = (row.get("method"), row.get("id"))

        if expiry_on_break and line_key in first_break_idx:
            exp_idx = int(first_break_idx[line_key])
            reason = "break"
        else:
            age = expiry_after_map.get(row["id"]) if isinstance(expiry_after_map, dict) else int(expiry_after_map)
            if age is None or pd.isna(age):
                age = int(row["end_idx"] - row["start_idx"] + 1)
            exp_idx = int(row["end_idx"]) + int(age)
            exp_idx = int(np.clip(exp_idx, 0, len(cal_index) - 1))
            reason = "age"

        expiry_rows.append({
            "event": "expiry",
            "side": "NONE",
            "idx": exp_idx,
            "date": cal_index[exp_idx] if isinstance(cal_index, pd.DatetimeIndex) else None,
            "price": np.nan,
            "confidence": 0.0,
            "method": row.get("method"),
            "line_id": row.get("id"),
            "start_idx": row.get("start_idx"),
            "meta": {"reason": reason}
        })
    expiry_df = pd.DataFrame(expiry_rows)

    # ---- combine
    base = ev_sorted[ev_sorted["event"].str.lower() != "break"]  # keep all non-break events
    out = pd.concat([base, breaks_first, create_df, expiry_df], ignore_index=True)
    out = out.sort_values(["method", "line_id", "idx"]).reset_index(drop=True)

    # ensure dates exist
    if "date" not in out.columns or out["date"].isna().any():
        pos = out["idx"].astype(int).clip(0, len(cal_index) - 1)
        out["date"] = cal_index.take(pos.to_numpy())

    return out
