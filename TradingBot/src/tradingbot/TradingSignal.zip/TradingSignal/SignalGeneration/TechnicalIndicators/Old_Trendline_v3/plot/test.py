import os, json
import pandas as pd
from tradingbot.TradingSignal.SignalGeneration.TechnicalIndicators.Old_Trendline_v3.runner import run_methods
from tradingbot.TradingSignal.SignalGeneration.TechnicalIndicators.Old_Trendline_v3.plot import plot_trendlines
from tradingbot.TradingSignal.SignalGeneration.TechnicalIndicators.Old_Trendline_v3.runner_json import run_from_json
from tradingbot.TradingSignal.SignalGeneration.IndicatorConfig.config_resolver import load_config_json, get_post_params
from tradingbot.TradingSignal.PostSingalGeneration.CombinedSingals import apply_confidence
from tradingbot.TradingSignal.PostSingalGeneration.SignalDecay import apply_decay_snapshot
from tradingbot.TradingSignal.SignalGeneration.TechnicalIndicators.Old_Trendline_v3.post import (
    synthesize_create_break_expiry
)

from tradingbot.TradingSignal.PostSingalGeneration.CombinedSingals.combined_strength_api_old import (   
    StrengthParams,
    get_combined_strength_from_snapshot,
    consolidate_buy_sell,
    compute_strength_timeseries,
    compute_snapshot_strength,
    snapshot_at,
    plot_strength_timeseries,
)


# 4a) choose params (align with your decay step)
params = StrengthParams(
    min_confidence=0.0,
    decay_lambda=0.12,              # same lambda you used in apply_decay_snapshot
    decay_hold=0,
    decay_threshold=0.25,
    cap_confidence_at_1=True,
    bound_mode="clip",
    bound_clip_value=1.0,
    include_pct_columns=True,
    include_indicator_columns=True,
    # Optional weights:
    method_weights={"ols": 0.20, "ols_shift_min":0.20,"ols_envelop":0.20,"huber":0.20,"hough": 0.20},
    side_weights={"BUY": 1.0, "SELL": 1.0},
    add_percentage_cols=True,           # alias (maps to include_pct_columns)
    indicator_column_prefix="ind_",
    indicator_list_delim=",",
)


pd.set_option("display.max_columns", None)
pd.set_option("display.width", 0)
pd.set_option("display.expand_frame_repr", False)

ROOT = os.environ.get("ZERODHA_ROOT", "/Users/ankit/Desktop/GitHub/AlgoTrading/QuantStrategies/TradingBot")
CSV_PATH = "/Users/ankit/Desktop/GitHub/AlgoTrading/QuantStrategies/TradingBot/data_SBIN.csv"

# --- config load (use mapping {method: params}) ---
cfg_raw = ROOT + "/src/tradingbot/TradingSignal/SignalGeneration/IndicatorConfig/tlc_config_methods.json"
cfg = load_config_json(cfg_raw)
post_cfg = get_post_params(cfg)   # picks expiry_after, expiry_on_break, etc.

# Accept both shapes: {"methods": {...}} or flat {...}
params_by_method = cfg["methods"] if isinstance(cfg, dict) and "methods" in cfg else cfg

# --- load OHLC and set DatetimeIndex ---
ohlc_data = pd.read_csv(CSV_PATH)
if "timestamp" in ohlc_data.columns:
    ohlc_data["timestamp"] = pd.to_datetime(ohlc_data["timestamp"])
    ohlc_data = ohlc_data.set_index("timestamp").sort_index()

# --- 1) run methods (choose which you want) ---
results = run_from_json(
    ohlc_data,
    methods=["ols", "huber"],                 # add "hough","ols_shift_min","ols_envelop" if desired
    json_path = cfg_raw
)

# Collect events and lines across methods
events = pd.concat(
    [res.events.assign(method=name) for name, res in results.items()],
    ignore_index=True
)
lines_df = pd.concat(
    [res.lines.assign(method=name) for name, res in results.items()],
    ignore_index=True
)


events = synthesize_create_break_expiry(
    events=events,
    lines=lines_df,
    cal_index=ohlc_data.index,
    expiry_after=post_cfg.get("expiry_after"),
    expiry_on_break=post_cfg.get("expiry_on_break", True),
)
# --- 2) Confidence (self-healing: will compute ref_px, idx, ATR if needed) ---
events = apply_confidence(
    events,
    method="trendline_distance",
    params={
        "norm_mode": "atr",
        "norm_k": 2.0,
        "cap": 1.0,
        "calendar_index": ohlc_data.index,          # derive idx from date if idx missing
        "lines": lines_df[["id", "m", "b"]],        # supply m,b for each line_id so ref_px can be built
        "ohlc": ohlc_data,                          # optional: let it compute ATR if events lack it
        "atr_length": 14
    }
)

# --- 3) Decay snapshot (choose the date you want) ---
snapshot = apply_decay_snapshot(
    events,
    target_date="2025-07-24",                      # YYYY-MM-DD
    method="exp",
    params={"lambda_": 0.12, "hold": 0, "threshold": 0.25},
    calendar_index=ohlc_data.index
)

print("events (with confidence):")
print(events.head(10))
print("\nstrength snapshot @ 2025-7-24:")
print(snapshot.tail(20))
snapshot.to_csv('event_testing.csv')


# 4b) If your snapshot is per-event with a decayed weight column, tell the API
#     which column to use (e.g. "decayed_weight", "weight", "w", or leave None if it's "confidence")
OUT = get_combined_strength_from_snapshot(
    snapshot_df=snapshot,
    snapshot_date="2025-07-24",     # only needed if snapshot lacks its own date column
    weight_column="decayed_weight", # try "weight" or "w" if that's what your snapshot uses
    **params.__dict__
)

strength_df = OUT["strength_df"]
latest      = OUT["snapshot"]

print("\n[combined] strength_df (tail):")
print(strength_df.tail(10))
print("\n[combined] latest snapshot dict:")
print(latest)

# 4c) Save and plot
strength_df.to_csv("combined_strength_timeseries.csv", index=True)

fig = plot_strength_timeseries(strength_df, title="Combined BUY/SELL/NET Strength")
fig.savefig("combined_strength_plot.png", dpi=140)