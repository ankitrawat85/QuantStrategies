from __future__ import annotations
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def _ensure_ohlc(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize OHLC: lower-case cols, derive a 'date' column, coerce numerics, drop bad rows."""
    o = df.copy()
    o.columns = [c.lower() for c in o.columns]

    # Build a proper date column from common possibilities
    if "date" in o.columns:
        o["date"] = pd.to_datetime(o["date"], errors="coerce")
    elif "timestamp" in o.columns:
        o["date"] = pd.to_datetime(o["timestamp"], errors="coerce")
    elif isinstance(o.index, pd.DatetimeIndex):
        o = o.assign(date=o.index.to_numpy())
    else:
        raise KeyError("No 'date'/'timestamp' column and index is not DatetimeIndex.")

    # Ensure required OHLC columns exist & numeric
    for c in ("open", "high", "low", "close"):
        if c not in o.columns:
            raise KeyError(f"Missing required column: {c}")
        o[c] = pd.to_numeric(o[c], errors="coerce")

    # Clean & make 0..N positional index
    o = o.dropna(subset=["date", "close"]).reset_index(drop=True)
    return o[["date", "open", "high", "low", "close"]]

def plot_trendlines(
    ohlc: pd.DataFrame,
    lines_df: pd.DataFrame,
    events_df: pd.DataFrame | None = None,
    title: str | None = None,
    out_path: str | None = None,
):
    """
    Draw price and OLS-style trendline segments.
    - lines_df needs: start_idx, end_idx, m, b
    - events_df optional: idx, price (for markers)
    """
    o = _ensure_ohlc(ohlc)
    if len(o) < 2:
        raise ValueError("OHLC has fewer than 2 rows after cleaning; nothing to plot.")

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(o["date"], o["close"], label="Close")

    # Plot segments y = m*x + b over x=[start_idx..end_idx] (position-based, so use iloc)
    if lines_df is not None and len(lines_df):
        L = lines_df.copy()
        for col in ("start_idx", "end_idx", "m", "b"):
            L[col] = pd.to_numeric(L[col], errors="coerce")
        L = L.dropna(subset=["start_idx", "end_idx", "m", "b"])

        # keep only segments within range and with positive length
        L["start_idx"] = L["start_idx"].astype(int)
        L["end_idx"]   = L["end_idx"].astype(int)
        valid = (
            (L["start_idx"] >= 0)
            & (L["end_idx"] < len(o))
            & (L["end_idx"] > L["start_idx"])
        )
        L = L.loc[valid]

        for _, r in L.iterrows():
            x0, x1 = int(r["start_idx"]), int(r["end_idx"])
            xs = np.arange(x0, x1 + 1, dtype=int)
            ys = float(r["m"]) * xs + float(r["b"])
            ax.plot(o["date"].iloc[xs], ys, linewidth=1.0, alpha=0.75)

    # Optional: event markers
    if events_df is not None and len(events_df):
        E = events_df.copy()
        if {"idx", "price"}.issubset(E.columns):
            E["idx"] = pd.to_numeric(E["idx"], errors="coerce")
            E["price"] = pd.to_numeric(E["price"], errors="coerce")
            E = E.dropna(subset=["idx", "price"])
            if len(E):
                idx = E["idx"].astype(int).clip(0, len(o) - 1).to_numpy()
                prc = E["price"].to_numpy()
                ax.scatter(o["date"].iloc[idx], prc, s=18, alpha=0.7, label="events")

    ax.set_title(title or "Trendlines")
    ax.set_xlabel("Date")
    ax.set_ylabel("Price")
    ax.grid(True, linestyle="--", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    if out_path:
        fig.savefig(out_path, dpi=140)
    return fig, ax
