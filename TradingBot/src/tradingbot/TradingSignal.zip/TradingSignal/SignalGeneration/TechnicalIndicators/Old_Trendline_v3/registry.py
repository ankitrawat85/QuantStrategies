
from __future__ import annotations
from typing import Dict, Callable
from tradingbot.TradingSignal.SignalGeneration.TechnicalIndicators.Old_Trendline_v3.interfaces import TrendlineMethod

_REGISTRY: Dict[str, Callable[[], TrendlineMethod]] = {}

def register_method(name: str):
    def _wrap(ctor: Callable[[], TrendlineMethod]):
        _REGISTRY[name.lower()] = ctor
        return ctor
    return _wrap

def get_method(name: str) -> TrendlineMethod:
    ctor = _REGISTRY.get(name.lower())
    if ctor is None:
        raise KeyError(f"Method '{name}' not registered. Available: {list(_REGISTRY)}")
    return ctor()

def available_methods():
    return sorted(_REGISTRY.keys())
