
from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import asdict
from sklearn.linear_model import LinearRegression

from ..registry import register_method
from ..types import LineFit, Event, MethodResult, MethodParams


# -------- helpers -----------------------------------------------------------

def _compute_atr(ohlc: pd.DataFrame, length: int = 14) -> pd.Series:
    o = ohlc["open"].astype(float).to_numpy()
    h = ohlc["high"].astype(float).to_numpy()
    l = ohlc["low"].astype(float).to_numpy()
    c = ohlc["close"].astype(float).to_numpy()
    prev_c = np.roll(c, 1); prev_c[0] = c[0]
    tr = np.maximum.reduce([h - l, np.abs(h - prev_c), np.abs(l - prev_c)])
    return pd.Series(tr, index=ohlc.index).rolling(length, min_periods=1).mean()


def _calc_tol_abs(ohlc: pd.DataFrame, i: int, win: int, m: float, b: float, params: MethodParams) -> float:
    tol_mode = str(params.get("tol_mode", "pct"))        # 'pct' | 'atr'
    tol_pct  = float(params.get("tol_pct", 0.005))       # 0.5% default
    atr_len  = int(params.get("tol_atr_len", 14))
    atr_k    = float(params.get("tol_atr_k", 1.0))

    if tol_mode == "atr":
        atr = _compute_atr(ohlc, atr_len)
        return float(atr.iloc[max(0, i - win):i].mean() * atr_k)

    mid_px = float(ohlc["close"].iloc[max(0, i - win):i].median())
    return mid_px * tol_pct


def _emit_create(events, method_name, line_id, i_minus_1, ohlc, side, r2, touches=None, tol_abs=None):
    price = float(ohlc["close"].iloc[i_minus_1])
    events.append(Event(
        event="create",
        side="NONE",
        idx=i_minus_1,
        date=ohlc.index[i_minus_1],
        price=price,
        confidence=float(max(0.0, min(1.0, r2))),  # simple: base on r2
        method=method_name,
        line_id=line_id,
        meta={"r2": r2, "touches": touches, "tol_abs": tol_abs}
    ))


@register_method("ols")
def _ctor():
    return OLS()


class OLS:
    name = "ols"

    def run(self, ohlc: pd.DataFrame, params: MethodParams) -> MethodResult:
        win = int(params.get("base_window", 40))
        x = np.arange(len(ohlc)).reshape(-1, 1)

        lines, events = [], []
        close_s = ohlc["close"]; high_s = ohlc["high"]; low_s = ohlc["low"]

        def roll_fit(y: np.ndarray, side: str):
            if len(y) < win:
                return
            model = LinearRegression()
            for i in range(win, len(y) + 1):
                yi = y[i - win:i]; xi = x[i - win:i]
                model.fit(xi, yi)
                m = float(model.coef_[0]); b = float(model.intercept_)
                r2 = float(model.score(xi, yi))

                line_id = f"{side}_{i - win}_{i - 1}"
                lines.append(LineFit(
                    id=line_id, side=side, m=m, b=b,
                    start_idx=i - win, end_idx=i - 1, r2=r2
                ))

                # ---- Events: CREATE, BREAK (true crossing), optional TOUCH/BOUNCE ----
                tol_abs = _calc_tol_abs(ohlc, i, win, m, b, params)
                _emit_create(events, self.name, line_id, i - 1, ohlc, side, r2, tol_abs=tol_abs)

                price = float(close_s.iloc[i - 1])
                line_px = float(m * (i - 1) + b)
                prev_i = i - 2
                prev_price = float(close_s.iloc[prev_i]) if prev_i >= 0 else price
                prev_line_px = float(m * prev_i + b) if prev_i >= 0 else line_px

                # true cross: prev on other side, now beyond band
                if side == 'R':
                    crossed = (prev_price <= prev_line_px + tol_abs) and (price > line_px + tol_abs)
                else:
                    crossed = (prev_price >= prev_line_px - tol_abs) and (price < line_px - tol_abs)

                emit_touch = bool(params.get("emit_touch", True))
                emit_bounce = bool(params.get("emit_bounce", True))

                if side == 'R':
                    touched = (not crossed) and (high_s.iloc[i - 1] >= line_px - tol_abs) and (price <= line_px + tol_abs)
                    bounced = touched and (price < prev_price) and (price <= line_px - tol_abs)
                else:
                    touched = (not crossed) and (low_s.iloc[i - 1] <= line_px + tol_abs) and (price >= line_px - tol_abs)
                    bounced = touched and (price > prev_price) and (price >= line_px + tol_abs)

                if crossed:
                    events.append(Event(
                        event="break",
                        side=("BUY" if side == 'R' else "SELL"),
                        idx=i - 1, date=ohlc.index[i - 1], price=price,
                        confidence=min(1.0, max(0.0, abs(price - line_px) / (abs(line_px) + 1e-9))),
                        method=self.name, line_id=line_id,
                        meta={"r2": r2, "tol_abs": tol_abs}
                    ))
                elif bounced and emit_bounce:
                    events.append(Event(
                        event="bounce",
                        side=("SELL" if side == 'R' else "BUY"),
                        idx=i - 1, date=ohlc.index[i - 1], price=price,
                        confidence=0.5,
                        method=self.name, line_id=line_id, meta={"r2": r2, "tol_abs": tol_abs}
                    ))
                elif touched and emit_touch:
                    events.append(Event(
                        event="touch",
                        side=("SELL" if side == 'R' else "BUY"),
                        idx=i - 1, date=ohlc.index[i - 1], price=price,
                        confidence=0.3,
                        method=self.name, line_id=line_id, meta={"r2": r2, "tol_abs": tol_abs}
                    ))

        roll_fit(ohlc["high"].to_numpy(), 'R')  # resistance
        roll_fit(ohlc["low"].to_numpy(), 'S')   # support

        lines_df = pd.DataFrame([asdict(l) for l in lines]) if lines else pd.DataFrame(
            columns=['id', 'side', 'm', 'b', 'start_idx', 'end_idx', 'r2', 'meta']
        )
        events_df = pd.DataFrame([asdict(e) for e in events]) if events else pd.DataFrame(
            columns=['event', 'side', 'idx', 'date', 'price', 'confidence', 'method', 'line_id', 'meta']
        )
        return MethodResult(lines=lines_df, events=events_df)
