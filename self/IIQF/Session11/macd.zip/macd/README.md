# macd
Moving average convergence divergence indicator 
