# roc
Rate of change
