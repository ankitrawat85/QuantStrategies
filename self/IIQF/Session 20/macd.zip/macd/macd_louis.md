### MACD Buy and Sell Signal
- Short term moving average = STMA
- Long term moving average = LTMA
- MACD = STMA - LTMA
- When STMA crosses LTMA from top, this is a signal to sell the stock
    - When MACD touches zero line from top, this is a signal to sell stock
- When STMA crosses LTMA from bottom, this is a signal to buy the stock
    - When MACD touches zero line from bottom, this is a signal to buy stock
